---
title: Java Quarkus
description: A Quarkus starter app.
tags:
  - Java
  - Quarkus
---

# Quarkus Example

This is a [Quarkus](https://quarkus.io) starter app that deploys to Railway.

[![Deploy on Railway](https://railway.com/button.svg)](https://railway.com/template/orZ9Pj?referralCode=D-ZQFL)

## ✨ Features

- Java
- Quarkus
